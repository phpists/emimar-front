import { useLocation } from "react-router";
import { NavLink } from "react-router";

export const Sidebar = () => {
  const { pathname } = useLocation();

  return (
    <div className="nk-apps-sidebar is-theme">
      <div className="nk-apps-brand">
        <NavLink to="/" className="logo-link">
          <img
            className="logo-light logo-img"
            src="/assets/images/logo-small.png"
            srcSet="/assets/images/logo-small2x.png 2x"
            alt="logo"
          />
          <img
            className="logo-dark logo-img"
            src="/assets/images/logo-dark-small.png"
            srcSet="/assets/images/logo-dark-small2x.png 2x"
            alt="logo-dark"
          />
        </NavLink>
      </div>
      <div className="nk-sidebar-element">
        <div className="nk-sidebar-body">
          <div
            className="nk-sidebar-content simplebar-scrollable-y"
            data-simplebar="init"
          >
            <div className="simplebar-wrapper" style={{ margin: 0 }}>
              <div className="simplebar-height-auto-observer-wrapper">
                <div className="simplebar-height-auto-observer" />
              </div>
              <div className="simplebar-mask">
                <div
                  className="simplebar-offset"
                  style={{ right: 0, bottom: 0 }}
                >
                  <div
                    className="simplebar-content-wrapper"
                    tabIndex={0}
                    role="region"
                    aria-label="scrollable content"
                    style={{ height: "100%", overflow: "hidden scroll" }}
                  >
                    <div className="simplebar-content" style={{ padding: 0 }}>
                      <div className="nk-sidebar-menu">
                        <ul className="nk-menu apps-menu">
                          <li
                            className={`nk-menu-item ${
                              pathname === "/" ? "active" : ""
                            }`}
                          >
                            <NavLink
                              to="/"
                              className={`nk-menu-link ${
                                pathname === "/" ? " active current-page " : ""
                              }`}
                              aria-label="Dashboard"
                              data-bs-original-title="Analytics Dashboard"
                            >
                              <span className="nk-menu-icon">
                                <em className="icon ni ni-table-view" />
                              </span>
                            </NavLink>
                          </li>
                          <li
                            className={`nk-menu-item ${
                              pathname === "/profile" ? "active" : ""
                            }`}
                          >
                            <NavLink
                              to="/profile"
                              className={`nk-menu-link ${
                                pathname === "/profile"
                                  ? " active current-page "
                                  : ""
                              }`}
                              aria-label="Profile"
                              data-bs-original-title="Profile settings"
                            >
                              <span className="nk-menu-icon">
                                <em className="icon ni ni-user-alt" />
                              </span>
                            </NavLink>
                          </li>{" "}
                          <li
                            className={`nk-menu-item ${
                              pathname === "/users" ? "active" : ""
                            }`}
                          >
                            <NavLink
                              to="/users"
                              className={`nk-menu-link ${
                                pathname === "/users"
                                  ? " active current-page "
                                  : ""
                              }`}
                              aria-label="Users"
                              data-bs-original-title="Profile settings"
                            >
                              <span className="nk-menu-icon">
                                <em class="icon ni ni-user-list"></em>{" "}
                              </span>
                            </NavLink>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="simplebar-placeholder"
                style={{ width: 79, height: 828 }}
              />
            </div>
            <div
              className="simplebar-track simplebar-horizontal"
              style={{ visibility: "hidden" }}
            >
              <div
                className="simplebar-scrollbar"
                style={{ width: 0, display: "none" }}
              />
            </div>
            <div
              className="simplebar-track simplebar-vertical"
              style={{ visibility: "visible" }}
            >
              <div
                className="simplebar-scrollbar"
                style={{
                  height: 399,
                  transform: "translate3d(0px, 176px, 0px)",
                  display: "block",
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
