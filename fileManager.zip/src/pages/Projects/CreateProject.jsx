import { useEffect } from "react";

export const CreateProject = ({ onClose }) => {
  useEffect(() => {
    const overlay = document.querySelector(".modal-backdrop");

    overlay.classList.add("show");

    return () => overlay.classList.remove("show");
  }, []);

  return (
    <div
      className="modal fade show"
      tabIndex={-1}
      id="modalCreateProject"
      aria-modal="true"
      role="dialog"
      style={{ display: "block" }}
    >
      <div className="modal-dialog" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Create Project</h5>
            <a
              href="#"
              className="close"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={onClose}
            >
              <em className="icon ni ni-cross" />
            </a>
          </div>

          <div className="modal-body">
            <form>
              <div className="form-group">
                <label className="form-label" htmlFor="project-name">
                  Project Name
                </label>
                <div className="form-control-wrap">
                  <input
                    type="text"
                    className="form-control"
                    id="project-name"
                    placeholder="Enter project name"
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="project-users">
                  Assign Users
                </label>
                <div className="form-control-wrap">
                  <select
                    id="project-users"
                    className="form-select js-select2"
                    multiple
                  >
                    <option value="1">Alice Johnson</option>
                    <option value="2">Bob Smith</option>
                    <option value="3">Charlie Brown</option>
                    <option value="4">Diana Prince</option>
                  </select>
                </div>
              </div>
            </form>
          </div>

          <div className="modal-footer bg-light">
            <button type="button" className="btn btn-primary">
              Create
            </button>
            <button
              type="button"
              className="btn btn-light"
              data-bs-dismiss="modal"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
