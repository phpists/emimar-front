export const baseUrl = "https://emimar-back.softdeal.site/api/";
