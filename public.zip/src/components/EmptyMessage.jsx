export const EmptyMessage = ({ title = "No data" }) => (
  <div className="nk-block-title page-title empty-message">{title}</div>
);
