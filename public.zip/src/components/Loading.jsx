export const Loading = () => (
  <div className="loading">
    <img src="/assets/images/loading.svg" alt="" />
  </div>
);
