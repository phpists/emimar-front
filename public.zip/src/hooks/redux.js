import { useSelector } from "react-redux";

export const useAppSelect = useSelector;
